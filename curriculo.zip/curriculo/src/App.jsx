import {Header} from './components/header/header'

import  Card  from './components/card'
import './App.css'


import './global.css'

function App() {

  return (
    <div>
      <Header />
      <Card />
    </div>
  )
}

export default App
