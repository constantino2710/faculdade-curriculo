import { div } from "framer-motion/client";
import { Carousel } from "./carousel/carousel";

export default function Card() {
	return(
		<div className='flex justify-center space-y-5'>

		<div className='bg-[var(--gray-800)] flex justify-center h-100 w-[80%] flex-col '>
			<h1 className='flex justify-center text-9xl'>Curriculo</h1>
			<Carousel />
		</div>
		</div>
	);
}